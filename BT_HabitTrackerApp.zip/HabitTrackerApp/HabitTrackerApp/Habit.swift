//
//  Habit.swift
//  HabitTrackerApp
//
//  Created by Brock Terry on 12/6/24.
//

struct Habit {
    var id: Int
    var name: String
    var frequency: String
    var startDate: String
    var streak: Int
}
