//
//  SQLiteManager.swift
//  HabitTrackerApp
//
//  Created by Brock Terry on 12/6/24.
//

import SQLite3
import Foundation

class SQLiteManager {
    static let shared = SQLiteManager()
    private var db: OpaquePointer?

    private init() {
        openDatabase()
        createTables()
    }

    private func openDatabase() {
        let fileURL = try! FileManager.default
            .url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("HabitTrackerApp.sqlite")

        if sqlite3_open(fileURL.path, &db) != SQLITE_OK {
            print("Error opening database.")
        } else {
            print("Database path: \(fileURL.path)")
        }
    }

    private func createTables() {
        let createHabitTableQuery = """
        CREATE TABLE IF NOT EXISTS Habit (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            frequency TEXT NOT NULL,
            startDate TEXT NOT NULL,
            streak INTEGER NOT NULL
        );
        """

        executeQuery(createHabitTableQuery, successMessage: "Habit table created.")
    }

    private func executeQuery(_ query: String, successMessage: String) {
        var statement: OpaquePointer?
        defer { sqlite3_finalize(statement) }

        if sqlite3_prepare_v2(db, query, -1, &statement, nil) == SQLITE_OK {
            if sqlite3_step(statement) == SQLITE_DONE {
                print(successMessage)
            } else {
                print("Failed to execute query: \(query)")
            }
        } else {
            let errorMessage = String(cString: sqlite3_errmsg(db))
            print("Error preparing statement: \(errorMessage)")
        }
    }

    func fetchHabits() -> [Habit] {
        let fetchQuery = "SELECT * FROM Habit;"
        var statement: OpaquePointer?
        var habits: [Habit] = []

        if sqlite3_prepare_v2(db, fetchQuery, -1, &statement, nil) == SQLITE_OK {
            while sqlite3_step(statement) == SQLITE_ROW {
                let id = Int(sqlite3_column_int(statement, 0))
                let name = String(cString: sqlite3_column_text(statement, 1))
                let frequency = String(cString: sqlite3_column_text(statement, 2))
                let startDate = String(cString: sqlite3_column_text(statement, 3))
                let streak = Int(sqlite3_column_int(statement, 4))

                let habit = Habit(id: id, name: name, frequency: frequency, startDate: startDate, streak: streak)
                habits.append(habit)
            }
        } else {
            let errorMessage = String(cString: sqlite3_errmsg(db))
            print("Error fetching habits: \(errorMessage)")
        }

        sqlite3_finalize(statement)
        print("Fetched Habits: \(habits)") // Debugging output
        return habits
    }

    func addHabit(_ habit: Habit) {
        let insertQuery = """
        INSERT INTO Habit (name, frequency, startDate, streak)
        VALUES (?, ?, ?, ?);
        """
        var statement: OpaquePointer?

        if sqlite3_prepare_v2(db, insertQuery, -1, &statement, nil) == SQLITE_OK {
            sqlite3_bind_text(statement, 1, (habit.name as NSString).utf8String, -1, nil)
            sqlite3_bind_text(statement, 2, (habit.frequency as NSString).utf8String, -1, nil)
            sqlite3_bind_text(statement, 3, (habit.startDate as NSString).utf8String, -1, nil)
            sqlite3_bind_int(statement, 4, Int32(habit.streak))

            if sqlite3_step(statement) == SQLITE_DONE {
                print("Habit added: \(habit)")
            } else {
                print("Failed to add habit.")
            }
        } else {
            let errorMessage = String(cString: sqlite3_errmsg(db))
            print("Error preparing insert statement: \(errorMessage)")
        }
        sqlite3_finalize(statement)
    }
    
    func clearDatabase() {
        let deleteQuery = "DELETE FROM Habit;"
        executeQuery(deleteQuery, successMessage: "Database cleared.")
    }

    func populateDatabase() {
        let sampleHabits = [
            Habit(id: 0, name: "Clean Room", frequency: "Weekly", startDate: getCurrentDate(), streak: 0),
            Habit(id: 0, name: "Brush Teeth", frequency: "Daily", startDate: getCurrentDate(), streak: 0),
            Habit(id: 0, name: "Shower", frequency: "Daily", startDate: getCurrentDate(), streak: 0),
            Habit(id: 0, name: "Clean House", frequency: "Monthly", startDate: getCurrentDate(), streak: 0),
            Habit(id: 0, name: "Clean Yard", frequency: "Monthly", startDate: getCurrentDate(), streak: 0),
            Habit(id: 0, name: "Read Book", frequency: "Weekly", startDate: getCurrentDate(), streak: 0),
            Habit(id: 0, name: "Exercise", frequency: "Daily", startDate: getCurrentDate(), streak: 0),
            Habit(id: 0, name: "Walk Dogs", frequency: "Daily", startDate: getCurrentDate(), streak: 0),
            Habit(id: 0, name: "Meditate", frequency: "Daily", startDate: getCurrentDate(), streak: 0),
            Habit(id: 0, name: "Cook Dinner", frequency: "Weekly", startDate: getCurrentDate(), streak: 0),
            Habit(id: 0, name: "Take Vitamins", frequency: "Daily", startDate: getCurrentDate(), streak: 0),
            Habit(id: 0, name: "Write Journal", frequency: "Weekly", startDate: getCurrentDate(), streak: 0)
        ]

        for habit in sampleHabits {
            addHabit(habit)
        }

        print("Database populated with sample habits.")
    }

    private func getCurrentDate() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: Date())
    }

    func updateHabit(_ habit: Habit) {
        let updateQuery = """
        UPDATE Habit
        SET name = ?, frequency = ?, startDate = ?, streak = ?
        WHERE id = ?;
        """
        var statement: OpaquePointer?

        if sqlite3_prepare_v2(db, updateQuery, -1, &statement, nil) == SQLITE_OK {
            sqlite3_bind_text(statement, 1, (habit.name as NSString).utf8String, -1, nil)
            sqlite3_bind_text(statement, 2, (habit.frequency as NSString).utf8String, -1, nil)
            sqlite3_bind_text(statement, 3, (habit.startDate as NSString).utf8String, -1, nil)
            sqlite3_bind_int(statement, 4, Int32(habit.streak))
            sqlite3_bind_int(statement, 5, Int32(habit.id))

            if sqlite3_step(statement) == SQLITE_DONE {
                print("Habit updated: \(habit)")
            } else {
                print("Failed to update habit.")
            }
        } else {
            let errorMessage = String(cString: sqlite3_errmsg(db))
            print("Error preparing update statement: \(errorMessage)")
        }
        sqlite3_finalize(statement)
    }

    func deleteHabit(by id: Int) {
        let deleteQuery = "DELETE FROM Habit WHERE id = ?;"
        var statement: OpaquePointer?

        if sqlite3_prepare_v2(db, deleteQuery, -1, &statement, nil) == SQLITE_OK {
            sqlite3_bind_int(statement, 1, Int32(id))

            if sqlite3_step(statement) == SQLITE_DONE {
                print("Habit deleted successfully!")
            } else {
                print("Failed to delete habit.")
            }
        } else {
            let errorMessage = String(cString: sqlite3_errmsg(db))
            print("Error preparing delete statement: \(errorMessage)")
        }
        sqlite3_finalize(statement)
    }
}
