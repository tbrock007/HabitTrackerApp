//
//  AddEditHabitViewController.swift
//  HabitTrackerApp
//
//  Created by Brock Terry on 12/6/24.
//

import UIKit

class AddEditHabitViewController: UIViewController {
    // MARK: - Outlets
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var frequencyPicker: UIPickerView!
    @IBOutlet weak var startDateLabel: UILabel!
    @IBOutlet weak var streakLabel: UILabel!

    // MARK: - Properties
    var habitToEdit: Habit? // The habit being edited (if any)
    let frequencies = ["Daily", "Weekly", "Monthly"]

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        configurePicker()
        populateFields()
    }

    // MARK: - Picker Configuration
    private func configurePicker() {
        frequencyPicker.delegate = self
        frequencyPicker.dataSource = self
    }

    private func populateFields() {
        if let habit = habitToEdit {
            nameTextField.text = habit.name
            if let index = frequencies.firstIndex(of: habit.frequency) {
                frequencyPicker.selectRow(index, inComponent: 0, animated: false)
            }
            startDateLabel.text = "Start Date: \(habit.startDate)"
            streakLabel.text = "Streak: \(habit.streak) days"
        } else {
            // Default values for a new habit
            startDateLabel.text = "Start Date: \(getCurrentDate())"
            streakLabel.text = "Streak: 0 days"
        }
    }

    // MARK: - Save Button
    @IBAction func saveButtonTapped(_ sender: UIBarButtonItem) {
        guard let name = nameTextField.text, !name.isEmpty else {
            showAlert(title: "Invalid Input", message: "Please enter a habit name.")
            return
        }

        let selectedFrequency = frequencies[frequencyPicker.selectedRow(inComponent: 0)]
        let currentDate = getCurrentDate()

        if var habit = habitToEdit {
            habit.name = name
            habit.frequency = selectedFrequency
            habit.startDate = currentDate
            habit.streak = 0 // Reset streak when editing
            SQLiteManager.shared.updateHabit(habit)
        } else {
            let newHabit = Habit(id: 0, name: name, frequency: selectedFrequency, startDate: currentDate, streak: 0)
            SQLiteManager.shared.addHabit(newHabit)
        }

        // Update labels with the current habit details
        startDateLabel.text = "Start Date: \(currentDate)"
        streakLabel.text = "Streak: 0 days"

        navigationController?.popViewController(animated: true)
    }
    

    // Helper method to get the current date
    private func getCurrentDate() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: Date())
    }

    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}

// MARK: - UIPickerViewDelegate, UIPickerViewDataSource
extension AddEditHabitViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return frequencies.count
    }

    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return frequencies[row]
    }
}
