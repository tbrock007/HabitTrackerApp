// HabitListViewController.swift

import UIKit

class HabitListViewController: UIViewController {
    // MARK: - Outlets
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var quoteLabel: UILabel! // New UILabel for displaying quotes

    // MARK: - Properties
    var habits: [Habit] = []

    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        configureTableView()
        loadHabits()
        fetchRandomQuote() // Fetch the first quote when the app loads
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadHabits()
    }

    // MARK: - Fetch Quotes
    private func fetchRandomQuote() {
        let urlString = "https://zenquotes.io/api/random"
        guard let url = URL(string: urlString) else {
            print("Invalid URL")
            return
        }

        let task = URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            if let error = error {
                print("Error fetching quote: \(error.localizedDescription)")
                return
            }

            guard let data = data else {
                print("No data received")
                return
            }

            do {
                // Parse the JSON response
                if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [[String: Any]],
                   let quote = json.first?["q"] as? String,
                   let author = json.first?["a"] as? String {
                    let fullQuote = "\"\(quote)\" - \(author)"

                    // Update the UI on the main thread
                    DispatchQueue.main.async {
                        self?.quoteLabel.text = fullQuote
                    }
                }
            } catch {
                print("Error parsing JSON: \(error.localizedDescription)")
            }
        }

        task.resume()
    }

    // MARK: - TableView Configuration
    private func configureTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "HabitCell")
    }

    // MARK: - Data Loading
    private func loadHabits() {
        habits = SQLiteManager.shared.fetchHabits()
        tableView.reloadData()
    }

    // MARK: - Navigation
    @IBAction func addHabitTapped(_ sender: UIBarButtonItem) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let addEditVC = storyboard.instantiateViewController(withIdentifier: "AddEditHabitViewController") as? AddEditHabitViewController {
            navigationController?.pushViewController(addEditVC, animated: true)
        }
    }
    
    @IBAction func clearButtonTapped(_ sender: UIBarButtonItem) {
        SQLiteManager.shared.clearDatabase()
        loadHabits()
        refreshQuote() // Fetch a new quote after clearing the database
    }

    @IBAction func populateButtonTapped(_ sender: UIBarButtonItem) {
        SQLiteManager.shared.populateDatabase()
        loadHabits()
        refreshQuote() // Fetch a new quote after populating the database
    }

    // Refresh quote after saving a new habit
    func refreshQuote() {
        fetchRandomQuote()
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension HabitListViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return habits.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HabitCell", for: indexPath)
        let habit = habits[indexPath.row]
        cell.textLabel?.text = habit.name
        cell.detailTextLabel?.text = "Frequency: \(habit.frequency) | Start: \(habit.startDate) | Streak: \(habit.streak)"
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)

        let habit = habits[indexPath.row]
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let addEditVC = storyboard.instantiateViewController(withIdentifier: "AddEditHabitViewController") as? AddEditHabitViewController {
            addEditVC.habitToEdit = habit
            navigationController?.pushViewController(addEditVC, animated: true)
        }
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let habitToDelete = habits[indexPath.row]
            SQLiteManager.shared.deleteHabit(by: habitToDelete.id)
            loadHabits()
        }
    }
}
